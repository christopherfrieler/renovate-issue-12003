# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['some_dependency']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'some-dependency',
    'version': '1.1.0',
    'description': 'an empty python package to be used as a dummy dependency',
    'long_description': None,
    'author': 'Christopher Frieler,',
    'author_email': 'christopher.frieler@dm.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/christopherfrieler/renovate-issue-12003',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<3.9',
}


setup(**setup_kwargs)
